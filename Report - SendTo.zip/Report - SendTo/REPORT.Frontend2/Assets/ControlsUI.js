 function stringsTrim(stringToTrim) {
     return stringToTrim.replace(/^\s+|\s+$/g, "");
 }

 function toggleOtherLanguages(groupName, hdnStatus) {
     if ($("#" + hdnStatus).attr("value") == "0") {
         $("tr." + groupName).show();
         $("img." + groupName).attr("src", "/Images/minus.jpg");
         $("#" + hdnStatus).attr("value", "1")
     } else {

         $("tr." + groupName).hide();
         $("img." + groupName).attr("src", "/Images/plus.jpg");
         $("#" + hdnStatus).attr("value", "0")
     }
 }

 function rotateProjectStatistics(CurrentIndexID, TotalCountID) {

     var currentIndex = parseInt(document.getElementById(CurrentIndexID).value);
     var TotalCount = parseInt(document.getElementById(TotalCountID).value);
     if (TotalCount > 0) {
         if (currentIndex > TotalCount) {
             currentIndex = 0;
         }


         $("tr.RotateHide").hide();
         $("tr.Rotate" + currentIndex).show();
         currentIndex++;

         document.getElementById(CurrentIndexID).value = currentIndex.toString();
     }
 }

 function FillChildDropDown(xmlPath, parentDropDownID, dropDownID, initialItemText) {

     var dropDownControl = document.getElementById(dropDownID);
     var parentDropDownControl = document.getElementById(parentDropDownID);

     dropDownControl.options.length = 0;

     var elOptSelect = document.createElement('option');

     elOptSelect.text = initialItemText;
     elOptSelect.value = '';

     dropDownControl.options.add(elOptSelect, dropDownControl.options.length);

     $.ajax({
         async: false,
         type: "GET",
         url: xmlPath + parentDropDownControl.value,
         dataType: "xml",
         success: function (xml) {
             $(xml).find('Values').each(function () {

                 $(xml).find('Value').each(function () {
                     var id = $(this).find('ID').text();
                     var name = $(this).find('Name').text();
                     var elOptNew = document.createElement('option');
                     elOptNew.text = name;
                     elOptNew.value = id;
                     dropDownControl.options.add(elOptNew, dropDownControl.options.length);

                 });
             });
         }
     });
 }








 function CollapseExpand() {
     $(function () {

         $('.panel-primary').not(':first').find('.panel-body').hide();
         $('.panel-primary:first').find('.panel-heading').addClass('active');
         $('.panel-heading,.panel-heading a.arrowServ').click(function (e) {
             e.preventDefault();
             var accordion = $(this).next('.panel-body');
             if (accordion.is(':hidden') != true) {
                 accordion.slideUp('normal');
                 $(this).toggleClass('active');

             } else {
                 accordion.slideDown('normal');
                 $(this).toggleClass('active');

             }


         });

     });
 }

 function OpenInvalidPanels()
 {
     var hasValid = $('.panel-body').has('.validation');

     hasValid.each(

     function (i) {
         if ($(this).is(':hidden')) {
             var validation = $(this).find(".validation");
             var firedValid = false;
             $(validation).each(function (i) {

                 var display = $(this).css("display");
                 var visibility = $(this).css("visibility");
                 if ((display != "none" && visibility == "hidden") || (display == "none" && visibility != "hidden"))
                 { }
                 else { firedValid = true }

             });

             if (firedValid) {
                 $(this).show();
                 $(this).prev(".panel-heading").addClass('active');
             }
         }

     });

     var errorDiv = $('.validation:visible').first();
     var scrollPos = errorDiv.offset().top - 10;
     $(window).scrollTop(scrollPos);

 }

 