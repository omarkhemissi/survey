﻿using System;
using System.Web;
using System.Web.UI.WebControls;

namespace REPORT.Frontend
{
    public partial class DefaultSiteMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}